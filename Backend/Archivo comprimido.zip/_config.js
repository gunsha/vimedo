module.exports = {
    'googleAuth' : {
      'clientID'      : '130888142811-nb54js01huhav2ja3aaln0sp6s0cj0em.apps.googleusercontent.com',
      'clientSecret'  : '40YN_J9CcW0zCJLBhNq6YhuR',
      'callbackURL'   : 'http://127.0.0.1:3000/usuarios/auth/google/callback'
    },
    'googleMaps':{
    	'apiKey':'AIzaSyA02b574ia3BpLXpDZXU2gOFuQZTfC_Kks',
    	'directionUrl':'https://maps.googleapis.com/maps/api/directions/json',
    	'geocodeUrl':'https://maps.googleapis.com/maps/api/geocode/json'
    }
};